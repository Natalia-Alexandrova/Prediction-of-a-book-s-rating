"""
Программа: Предобработка данных
Версия: 1.0
"""

import json
import warnings
import pandas as pd

warnings.filterwarnings("ignore")


def date_transform(data: pd.DataFrame, date_columns: dict, copy_columns: dict) -> pd.DataFrame:
    """
    Препроцессинг данных, содержащих дату
    :param data: датасет
    :param date_columns: словарь признаков, которые содержат дату
    :param copy_columns: названия новых признаков, созданных на основе имеющихся
    :return: датасет
    """

    for k1, v1 in date_columns.items():
        data[v1] = data[k1].str[-4:]

    for k2, v2 in copy_columns.items():
        data[v2] = data[k2].astype(int)

    return data


def transform_types(data: pd.DataFrame, change_type_columns: dict) -> pd.DataFrame:
    """
    Преобразование признаков в заданный тип данных
    :param data: датасет
    :param change_type_columns: словарь с признаками и типами данных
    :return: датасет
    """

    return data.astype(change_type_columns, errors="raise")


def get_bins(data: (int, float),
             first_val: (int, float),
             second_val: (int, float),
             labels: list) -> pd.DataFrame:
    """
    Генерация бинов для признаков
    :param data: датасет
    :param first_val: первый порог значения для разбиения на бины
    :param second_val: второй порог значения для разбиения на бины
    :param labels: метки бинов
    :return: датасет
    """

    assert isinstance(data, (int, float)), "Проблема с типом данных в признаке"
    result = (
        labels[0]
        if data <= first_val
        else labels[1]
        if first_val < data <= second_val
        else labels[2]
    )
    return result


def check_columns_evaluate(data: pd.DataFrame, unique_values_path: str) -> pd.DataFrame:
    """
    Проверка на наличие признаков из train и упорядочивание признаков согласно train
    :param data: датасет test
    :param unique_values_path: путь до списока с признаками train для сравнения
    :return: датасет test
    """

    with open(unique_values_path) as json_file:
        unique_values = json.load(json_file)

    column_sequence = unique_values.keys()

    assert set(column_sequence) == set(data.columns), "Разные признаки"
    return data[column_sequence]


def save_unique_train_data(
        data: pd.DataFrame, drop_columns: list, target_column: str, unique_values_path: str
) -> None:
    """
    Сохранение словаря с признаками и уникальными значениями
    :param drop_columns: список с признаками для удаления
    :param data: датасет
    :param target_column: целевая переменная
    :param unique_values_path: путь до файла со словарем
    :return: None
    """

    unique_df = data.drop(
        columns=drop_columns + [target_column], axis=1, errors="ignore"
    )
    # создаем словарь с уникальными значениями для вывода в UI
    dict_unique = {key: unique_df[key].unique().tolist() for key in unique_df.columns}
    with open(unique_values_path, "w") as file:
        json.dump(dict_unique, file)


def pipeline_preprocess(data: pd.DataFrame,  **kwargs):
    """
    Пайплайн по полной предобработке данных
    :param data: датасет
    :return: датасет
    """

    # обработка даты
    date_transform(data, kwargs["date_transform"], kwargs["copy"])

    # создание бинов
    for key in kwargs["map_bins_columns"].keys():
        data[key] = data[key].apply(
            lambda x: get_bins(
                x,
                first_val=kwargs["map_bins_columns"][key][0][0],
                second_val=kwargs["map_bins_columns"][key][0][1],
                labels=kwargs["map_bins_columns"][key][1]
            ))

    # изменение типа данных
    data = transform_types(data=data, change_type_columns=kwargs["change_type_columns"])

    # удалнение колонок
    data = data.drop(kwargs["drop_columns"], axis=1, errors="ignore")

    # либо сохранение уникальных данных с признаками из train
    save_unique_train_data(
        data=data,
        drop_columns=kwargs["drop_columns"],
        target_column=kwargs["target_column"],
        unique_values_path=kwargs["unique_values_path"],
        )

    return data


def pipeline_preprocess_predict(data: pd.DataFrame, **kwargs):
    """
    Пайплайн по предобработке данных для предсказания
    :param data: датасет
    :return: датасет
    """

    # изменение типа данных
    data = transform_types(data=data, change_type_columns=kwargs["change_type_century"])
    data = transform_types(data=data, change_type_columns=kwargs["change_type_columns"])

    # проверка соответствия признаков для выборок test и train
    data = check_columns_evaluate(
        data=data, unique_values_path=kwargs["unique_values_path"]
    )

    return data
