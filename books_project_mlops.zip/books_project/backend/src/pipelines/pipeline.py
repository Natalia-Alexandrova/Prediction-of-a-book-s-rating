"""
Программа: Сборный конвейер для тренировки модели
Версия: 1.0
"""

import os
import joblib
import yaml

from ..data.split_dataset import split_train_test
from ..train.train import find_optimal_params, train_model
from ..data.get_data import get_dataset
from ..transform.transform import pipeline_preprocess


def pipeline_training(config_path: str) -> None:
    """
    Полный цикл получения данных, предобработки и тренировки модели
    :param config_path: путь до файла с конфигурациями
    :return: None
    """

    # get params
    with open(config_path) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
    preprocessing_config = config["preprocessing"]
    train_config = config["train"]

    # get data
    data = get_dataset(dataset_path=preprocessing_config['raw_data_path'])

    # preprocessing
    data = pipeline_preprocess(data=data, flg_evaluate=False, **preprocessing_config)

    # split data
    data_train, data_test = split_train_test(dataset=data, **preprocessing_config)

    # find optimal params
    study = find_optimal_params(data_train=data_train, data_test=data_test, **train_config)

    # train with optimal params
    cat = train_model(
        data_train=data_train,
        data_test=data_test,
        study=study,
        target=train_config["target_column"],
        metric_path=train_config["metrics_path"],
    )

    # save result (study, model)
    joblib.dump(cat, os.path.join(train_config["model_path"]))
    joblib.dump(study, os.path.join(train_config["study_path"]))
