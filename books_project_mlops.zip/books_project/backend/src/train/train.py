"""
Программа: Тренировка данных
Версия: 1.0
"""

import optuna
from catboost import CatBoostRegressor, Pool

from optuna import Study, trial

from sklearn.model_selection import KFold, train_test_split
from sklearn.metrics import mean_absolute_error
import pandas as pd
import numpy as np
from ..data.split_dataset import get_train_test_data
from ..train.metrics import save_metrics


def objective(
        trial,
        data_x: pd.DataFrame,
        data_y: pd.Series,
        cat_feat: list,
        n_folds: int = 5,
        random_state: int = 10,
) -> np.array:
    """
    Целевая функция для поиска параметров
    :param trial: кол-во trials
    :param data_x: данные объект-признаки
    :param data_y: данные с целевой переменной
    :param cat_feat: лист с названиями категориальных признаков
    :param n_folds: кол-во фолдов
    :param random_state: random_state
    :return: среднее значение метрики по фолдам
    """

    # изменяемые гиперпараметры
    params = {"random_state": trial.suggest_categorical("random_state", [random_state]),
              "cat_features": trial.suggest_categorical("cat_features", [cat_feat]),
              "eval_metric": trial.suggest_categorical("eval_metric", ["MAE"]),

              "iterations": trial.suggest_categorical("iterations", [800]),
              "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.1),
              "max_depth": trial.suggest_int("max_depth", 4, 8, step=2),
              "l2_leaf_reg": trial.suggest_uniform("l2_leaf_reg", 1e-5, 1e2),
              'random_strength': trial.suggest_uniform('random_strength', 0.5, 25),
              'border_count': trial.suggest_categorical('border_count', [32, 128]),
              "bootstrap_type": trial.suggest_categorical("bootstrap_type", ["Bayesian", "Bernoulli", "MVS", "No"]),
              'grow_policy': trial.suggest_categorical('grow_policy', ["SymmetricTree", "Depthwise", "Lossguide"]),
              "boosting_type": trial.suggest_categorical("boosting_type", ['Plain'])
              }

    if params["bootstrap_type"] == "Bayesian":
        params["bagging_temperature"] = trial.suggest_float(
            "bagging_temperature", 0, 100)
    elif params["bootstrap_type"] == "Bernoulli":
        params["subsample"] = trial.suggest_float(
            "subsample", 0.1, 1, log=True)

    cv = KFold(n_splits=n_folds, shuffle=True, random_state=random_state)

    cv_predicts = np.empty(n_folds)

    for idx, (train_idx, test_idx) in enumerate(cv.split(data_x, data_y)):
        x_train, x_test = data_x.iloc[train_idx], data_x.iloc[test_idx]
        y_train, y_test = data_y.iloc[train_idx], data_y.iloc[test_idx]

        train_data = Pool(data=data_x, label=data_y, cat_features=cat_feat)
        eval_data = Pool(data=data_x, label=data_y, cat_features=cat_feat)

        model = CatBoostRegressor(**params)
        model.fit(
            train_data,
            eval_set=eval_data,
            early_stopping_rounds=100,
            verbose=0,
        )

        preds = model.predict(x_test)
        cv_predicts[idx] = mean_absolute_error(y_test, preds)

    return np.mean(cv_predicts)


def find_optimal_params(
        data_train: pd.DataFrame, data_test: pd.DataFrame, **kwargs
) -> Study:
    """
    Пайплайн для тренировки модели
    :param data_train: датасет train
    :param data_test: датасет test
    :return: [LGBMClassifier tuning, Study]
    """

    x_train, x_test, y_train, y_test = get_train_test_data(
        data_train=data_train, data_test=data_test, target=kwargs["target_column"]
    )

    cat_features = x_train.select_dtypes("category").columns.tolist()

    study = optuna.create_study(
        direction="minimize",
        pruner=optuna.pruners.SuccessiveHalvingPruner(),
        study_name="Catboost",
    )
    function = lambda trial: objective(
        trial, x_train, y_train, cat_features, kwargs["n_folds"], kwargs["random_state"]
    )
    study.optimize(function, n_trials=kwargs["n_trials"], show_progress_bar=True)

    return study


def train_model(
        data_train: pd.DataFrame,
        data_test: pd.DataFrame,
        study: Study,
        target: str,
        metric_path: str,
) -> CatBoostRegressor:
    """
    Обучение модели на лучших параметрах
    :param data_train: тренировочный датасет
    :param data_test: тестовый датасет
    :param study: study optuna
    :param target: название целевой переменной
    :param metric_path: путь до папки с метриками
    :return: CatBoostRegressor
    """

    x_train, x_test, y_train, y_test = get_train_test_data(
        data_train=data_train, data_test=data_test, target=target
    )

    # training optimal params
    cat = CatBoostRegressor(
        **study.best_params, silent=True)

    cat.fit(x_train, y_train, verbose=0)

    # save metrics
    save_metrics(data_x=x_test, data_y=y_test, model=cat, metric_path=metric_path)
    return cat
