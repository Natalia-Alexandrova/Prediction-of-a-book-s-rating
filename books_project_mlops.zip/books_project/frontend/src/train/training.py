"""
Программа: Тренировка модели на backend, отображение метрик и
графиков обучения на экране
Версия: 1.0
"""

import os
import json
import joblib
import requests
import streamlit as st
from optuna.visualization import plot_param_importances, plot_optimization_history


def start_training(config: dict, endpoint: object) -> None:
    """
    Обучение модели с выводом результатов
    :param config: конфигурационный файл
    :param endpoint: endpoint
    """

    # Загрузка метрик с прошлого шага
    if os.path.exists(config["train"]["metrics_path"]):
        with open(config["train"]["metrics_path"]) as json_file:
            old_metrics = json.load(json_file)
    else:
        # если до этого не обучали модель и нет прошлых значений метрик
        old_metrics = {"MAE": 0, "MSE": 0, "R2": 0, "MAPE": 0, "WAPE": 0}

    # Обучение
    with st.spinner("Модель подбирает параметры..."):
        output = requests.post(endpoint, timeout=8000)
    st.success("Выполнено")

    new_metrics = output.json()["metrics"]

    # Метрики
    mae, mse, r2, mape, wape = st.columns(5)
    mae.metric(
        "MAE",
        new_metrics["MAE"],
        f"{new_metrics['MAE']-old_metrics['MAE']:.3f}",
    )
    mse.metric(
        "MSE",
        new_metrics["MSE"],
        f"{new_metrics['MSE']-old_metrics['MSE']:.3f}",
    )
    r2.metric(
        "R2",
        new_metrics["R2"],
        f"{new_metrics['R2']-old_metrics['R2']:.3f}",
    )
    mape.metric(
        "MAPE",
        new_metrics["MAPE"],
        f"{new_metrics['MAPE']-old_metrics['MAPE']:.3f}"
    )
    wape.metric(
        "WAPE",
        new_metrics["WAPE"],
        f"{new_metrics['WAPE']-old_metrics['WAPE']:.3f}",
    )

    # plot study
    study = joblib.load(os.path.join(config["train"]["study_path"]))
    fig_imp = plot_param_importances(study)
    fig_history = plot_optimization_history(study)

    st.plotly_chart(fig_imp, use_container_width=True)
    st.plotly_chart(fig_history, use_container_width=True)
