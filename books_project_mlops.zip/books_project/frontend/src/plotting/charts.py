"""
Программа: Отрисовка графиков
Версия: 1.0
"""

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns


def boxplot(
        data: pd.DataFrame, col_main: str, col_group: str, title: str
) -> matplotlib.figure.Figure:
    """
    Отрисовка графика boxplot
    :param data: датасет
    :param col_main: признак для анализа
    :param col_group: признак для группировки
    :param title: название графика
    :return: поле рисунка
    """

    sns.set_style("whitegrid")
    fig = plt.figure(figsize=(15, 7))

    data = data[data[col_group] != '0']

    sns.boxplot(
        data=data, x=col_group, y=col_main, palette="viridis")

    plt.title(title, fontsize=20)
    plt.ylabel(col_main, fontsize=14)
    plt.xlabel(col_group, fontsize=14)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    return fig


def kdeplotting(
        data: pd.DataFrame, data_x: str, hue: str, title: str
) -> matplotlib.figure.Figure:
    """
    Отрисовка графика kdeplot
    :param data: датасет
    :param data_x: ось OX
    :param hue: группирвока по признаку
    :param title: название графика
    :return: поле рисунка
    """

    sns.set_style("whitegrid")

    fig = plt.figure(figsize=(15, 7))

    sns.kdeplot(
        data=data, x=data_x, hue=hue, palette="rocket", common_norm=False, fill=True
    )
    plt.title(title, fontsize=20)
    plt.xlabel(data_x, fontsize=14)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    return fig


def scatterplotting(
        data: pd.DataFrame, data_x: str, data_y: str, title: str
) -> matplotlib.figure.Figure:
    """
    Отрисовка графика kdeplot
    :param data: датасет
    :param data_x: ось OX
    :param data_y: ось OY
    :param title: название графика
    :return: поле рисунка
    """

    sns.set_style("whitegrid")

    fig = plt.figure(figsize=(15, 7))

    sns.scatterplot(data=data, y=data_y, x=data_x)

    plt.title(title, fontsize=20)
    plt.ylabel(data_y, fontsize=14)
    plt.xlabel(data_x, fontsize=14)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)

    return fig
