"""
Программа: Отрисовка слайдеров и кнопок для ввода данных
с дальнейшим получением предсказания на основании введенных значений
Версия: 1.0
"""

import json
from io import BytesIO
import pandas as pd
import requests
import streamlit as st


def evaluate_input(unique_data_path: str, endpoint: object) -> None:
    """
    Получение входных данных путем ввода в UI -> вывод результата
    :param unique_data_path: путь до уникальных значений
    :param endpoint: endpoint
    """

    with open(unique_data_path) as file:
        unique_df = json.load(file)

    # поля для вводы данных, используем уникальные значения
    authors = st.text_input("authors")

    language_code = st.sidebar.selectbox("language_code", (unique_df["language_code"]))

    num_pages = st.sidebar.number_input(
        "num_pages",
        min_value=min(unique_df["num_pages"]),
        max_value=max(unique_df["num_pages"])
    )

    ratings_count = st.sidebar.number_input(
        "rating_counts",
        min_value=min(unique_df["ratings_count"]),
        max_value=max(unique_df["ratings_count"]),
    )

    publisher = st.text_input("publisher")

    genre = st.sidebar.selectbox("genre", (unique_df["genre"]))

    publication_year = st.sidebar.number_input(
        "publication_year",
        min_value=min(unique_df["publication_year"]),
        max_value=max(unique_df["publication_year"])
    )

    century = st.sidebar.selectbox("century", (unique_df["century"]))

    dict_data = {
        "authors": authors,
        "language_code": language_code,
        "num_pages": num_pages,
        "ratings_count": ratings_count,
        "publisher": publisher,
        "genre": genre,
        "publication_year": publication_year,
        "century": century
        }

    st.write(
        f"""### Описание книги:\n
    1) authors: {dict_data['authors']}
    2) language_code: {dict_data['language_code']}
    3) num_pages: {dict_data['num_pages']}
    4) ratings_count: {dict_data['ratings_count']}
    5) publisher: {dict_data['publisher']}
    6) genre: {dict_data['genre']}
    7) publication_year: {dict_data['publication_year']}
    8) century: {dict_data['century']}
    """
    )

    # evaluate and return prediction (text)
    button_ok = st.button("Прогноз")
    if button_ok:
        result = requests.post(endpoint, timeout=8000, json=dict_data)
        json_str = json.dumps(result.json())
        output = json.loads(json_str)
        st.write(f"## {output}")
        st.success("Выполнено")


def evaluate_from_file(data: pd.DataFrame, endpoint: object, files: BytesIO):
    """
    Получение входных данных в качестве файла -> вывод результата в виде таблицы
    :param data: датасет
    :param endpoint: endpoint
    :param files:
    """
    button_ok = st.button("Прогноз")
    if button_ok:
        # заглушка так как не выводим все предсказания
        data_ = data[:5]
        output = requests.post(endpoint, files=files, timeout=8000)
        data_["rating_predict"] = output.json()["prediction"]
        st.write(data_.head())
