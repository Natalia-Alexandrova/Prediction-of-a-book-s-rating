"""
Программа: Frontend часть проекта
Версия: 1.0
"""

import os

import yaml
import streamlit as st
from src.data.get_data import load_data, get_dataset
from src.plotting.charts import boxplot, kdeplotting, scatterplotting
from src.train.training import start_training
from src.evaluate.evaluate import evaluate_input, evaluate_from_file

CONFIG_PATH = "../config/params.yml"


def main_page():
    """
    Страница с описанием проекта
    """
    st.image(
        "https://avatars.mds.yandex.net/i?id=addac9ee9685f98a45cd533636e08ddb_l-4033947-images-thumbs&n=13.jpg",
        width=600,
    )

    st.markdown("# Описание проекта")
    st.markdown("## MLOps project: Prediction of a book rating")
    st.write(
        """
        Чтобы планировать закупку прав на книги, онлайн библиотеке 
        необходима модель для прогнозирования рейтинга книг по признаковому описанию."""
    )
    st.markdown(
        """Ссылка на датасет: https://www.kaggle.com/datasets/jealousleopard/goodreadsbooks"""
    )
    st.markdown(
        """
        ### Состав данных:
            - bookID - Уникальный идентификатор
            - authors - Авторы книги
            - language_code - Язык кники
            - num_pages - Количество страниц в книге
            - ratings_count - Количество оценок
            - publication_year - Год публикации
            - century - Век публикации
            - publisher - Название издалельства
            - genres - Жанр
            
            Target:
            - average_rating - Рейтинг книги [0, 5]
    """
    )


def exploratory():
    """
    Анализ данных
    """

    st.markdown("# Разведочный анализ данных")

    with open(CONFIG_PATH) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)

    # загрузка датасета
    data = get_dataset(dataset_path=config["preprocessing"]["train_path"])
    st.write(data.head())

    # чекбоксы
    rating_distribution = st.sidebar.checkbox("Распределение рейтинга в датасете")
    num_pages_rating = st.sidebar.checkbox("Количество страниц - Рейтинг")
    century_rating = st.sidebar.checkbox("Век - Рейтинг")
    genre_rating = st.sidebar.checkbox("Жанр - Рейтинг")

    if rating_distribution:
        st.pyplot(
            kdeplotting(
                data=data,
                data_x="average_rating",
                hue=None,
                title="Плотность вероятности распределение рейтинга",
            )
        )
        st.markdown("""Распределение рейтинга книг имеет вид нормального распределения с mean = 3.93, std = 0.35.
                        Основной разброс оценок определяется в диапазоне от 3 до 5 баллов. 
                        Так наиболее вероятная оценка = 3.93, то книги рейтингом 4 и более
                        потенциально будут востребованны. Однако количество высоких оценок 
                        ( в диапазоне [4.5, 5] ) маловероятно, значит при планировании закупок прав
                        основной фокус важно держать  на произведениях с рейтингом от 4 до 4.5.""")

    if num_pages_rating:
        st.pyplot(
            scatterplotting(
                data=data,
                data_x="average_rating",
                data_y="num_pages",
                title="Связь рейтинга книги и количества страниц",
            )
        )

        st.markdown(""" Количество страниц слабо коррелярует с рейтингом произведения.
                        Для книг с рейтингом как с низким рейтингом [3, 3.5], так и с высоким 
                        [4.5, 5] свойственно меньшее количество страниц (до 400).
                        В то время как книги с хорошими оценками представлены во всём 
                        диапазоне количества страниц (до 850).""")

    if century_rating:
        st.pyplot(
            boxplot(
                data=data,
                col_main="average_rating",
                col_group="century",
                title="Связь рейтинга произведения и века публикации",
            )
        )

        st.markdown(""" Для произведений первой половины 20-го века свойственно 
                        более высокое значение медианы, меньший межквантильный 
                        диапазон вместе с более узким диапазоном макс-мин значений. 
                        Это означает, что в этой группе книг оценки наиболее вероятно 
                        распределены около среднего рейтинга (рейтинга = 4). 
                        Для книг второй половины 20-го века и 21 века свойтвеннен 
                        практически одинаково широкое распредение рейтинга (от 3.3 до 4.7). 
                        Однако, медиана для группы книг 21 века лежит чуть ниже. """)

    if genre_rating:
        st.pyplot(
            boxplot(
                data=data,
                col_main="average_rating",
                col_group="genre",
                title="Связь рейтинга произведения и жанра",
            )
        )

        st.markdown(""" Лидирующие позиции по рейтингу занимают книги, написанные в 
                        в жанрах Sequential Art, Children и Fantasy. По границе максимальных значений
                        замечено, то книги в жанрах Sequential Art и Nonfiction принимают наибольшие значения.""")


def training():
    """
    Обучение модели
    """

    st.markdown("# Обучение CatBoost")
    # получение параметров
    with open(CONFIG_PATH) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
    # endpoint
    endpoint = config["endpoints"]["train"]

    if st.button("Начать обучение"):
        start_training(config=config, endpoint=endpoint)


def prediction():
    """
    Получение предсказаний путем ввода данных
    """

    st.markdown("# Предсказание по описанию")
    with open(CONFIG_PATH) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
    endpoint = config["endpoints"]["prediction_input"]
    unique_data_path = config["preprocessing"]["unique_values_path"]

    # проверка на наличие сохраненной модели
    if os.path.exists(config["train"]["model_path"]):
        evaluate_input(unique_data_path=unique_data_path, endpoint=endpoint)
    else:
        st.error("Сначала обучите модель")


def prediction_from_file():
    """
    Получение предсказаний для файла с данными
    """

    st.markdown("# Предсказание для файла")
    with open(CONFIG_PATH) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
    endpoint = config["endpoints"]["prediction_from_file"]

    upload_file = st.file_uploader(
        "", type=["csv", "xlsx"], accept_multiple_files=False
    )
    # проверка загружен ли файл
    if upload_file:
        dataset_csv_df, files = load_data(data=upload_file, type_data="Test")
        # проверка на наличие сохраненной модели
        if os.path.exists(config["train"]["model_path"]):
            evaluate_from_file(data=dataset_csv_df, endpoint=endpoint, files=files)
        else:
            st.error("Сначала обучите модель")


def main():
    """
    Сборка страницы
    """

    page_names_to_funcs = {
        "Описание проекта": main_page,
        "Разведочный анализ данных": exploratory,
        "Обучение модели": training,
        "Предсказание по вводу": prediction,
        "Предсказание для файла": prediction_from_file,
    }
    selected_page = st.sidebar.selectbox("Выберите пункт", page_names_to_funcs.keys())
    page_names_to_funcs[selected_page]()


if __name__ == "__main__":
    main()
